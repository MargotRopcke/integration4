import { BackButton } from "../components/BackButton";
import { StepProgress } from "../components/StepProgress";
export function StepVibes({ vibes, chosenCategory, selectedVibes, onToggle, onDone, onBack }) {
  const filtered = vibes.filter((v) => v.primary_category_id === chosenCategory?.id);

  return (
    <div className="step-container" id="step-4">
      <BackButton onClick={onBack} />
      <div className="form-header">
        <h1 className="form-heading">Choose the vibe(s) that fit your taste:</h1>
        <p className="form-subheading">Your taste shapes a more personal journey.</p>
      </div>
      <div className="vibes-grid">
        {filtered.map((vibe) => {
          const name = vibe.name.trim();
          const isSelected = selectedVibes.includes(name);
          return (
            <div
              key={vibe.id}
              onClick={() => onToggle(name)}
              className={`vibe-option ${isSelected ? "selected" : ""}`}
              id={`vibe-${name.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="vibe-circle"><div className="vibe-dot" /></div>
              <span className="vibe-text">{name}</span>
            </div>
          );
        })}
      </div>
      <div className="vibes-actions">
        <button onClick={onDone} className="btn-form" id="done-button">Done</button>
      </div>
      <StepProgress current={4} total={6} />
    </div>
  );
}
